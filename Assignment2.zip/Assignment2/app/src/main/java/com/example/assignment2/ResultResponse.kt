package com.example.assignment2

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResultResponse(val resultCount: Int,val results: List<SongInfo> ):Parcelable

@Parcelize
data class SongInfo(val artistName: String,
                    val collectionName: String,
                    val artworkUrl60: String,
                    val trackPrice: Double,
                    val previewUrl: String,
                    ): Parcelable

