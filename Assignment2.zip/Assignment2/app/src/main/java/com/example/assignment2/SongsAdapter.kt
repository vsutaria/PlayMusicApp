package com.example.assignment2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class SongsAdapter ( val dataSet: ResultResponse,val activityCallback: (song:SongInfo)-> Unit)
    : RecyclerView.Adapter<SongsAdapter.SongsViewHolder>(){


    class SongsViewHolder (val songView: View): RecyclerView.ViewHolder(songView){
        private val songImage:ImageView =songView.findViewById(R.id.song_image_iv)
        private val songName:TextView =songView.findViewById(R.id.song_name_et)
        private val songArtist:TextView =songView.findViewById(R.id.artist_name_et)
        private val songPrice:TextView =songView.findViewById(R.id.price_et)






        fun onBind(song: SongInfo, playSong: (song: SongInfo)->Unit){
            songView.setOnClickListener {
                playSong.invoke(song)
            }

            songName.text= song.collectionName
            songArtist.text = song.artistName
            songPrice.text= song.trackPrice.toString()
            Picasso.get().load(song.artworkUrl60).into(songImage)

        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongsViewHolder {
        return SongsViewHolder(LayoutInflater.from(parent.context).inflate(
                R.layout.fragment_display_song,parent,false
        ))
    }

    override fun onBindViewHolder(holder: SongsViewHolder, position: Int) {
        holder.onBind(dataSet.results[position],activityCallback)
    }

    override fun getItemCount(): Int {
        return dataSet.resultCount
    }

}