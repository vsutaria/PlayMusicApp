package com.example.assignment2

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        CallAPI("Rock")
        swipeRefresh.setOnRefreshListener {


            CallAPI(tab_layout.selectedTabPosition.toString() )
        }

        tab_layout.selectTab(tab_layout.getTabAt(1))
        tab_layout.selectTab(tab_layout.getTabAt(0))
        tab_layout.addOnTabSelectedListener(
            object : OnTabSelectedListener {

                override fun onTabSelected(tab: TabLayout.Tab) {

                    var selectedTab = tab.text

                    CallAPI(selectedTab.toString() )

                }

                override fun onTabUnselected(tab: TabLayout.Tab) {}
                override fun onTabReselected(tab: TabLayout.Tab) {}
            }
        )
        }
    @SuppressLint("ResourceType")
    private fun openActivityDetails(song: SongInfo){
            val intent = Intent()
            intent.action = Intent.ACTION_VIEW
            intent.setDataAndType(Uri.parse(song.previewUrl), "audio/mp3")
            startActivity(intent)
        }


    private fun CallAPI(selectedTab: String){
        println("$selectedTab hellloo FUCK")
        if (selectedTab.equals("Rock")){

            SongsAPI.initRetrofit().getRockSongs().enqueue(
                    object: Callback<ResultResponse> {
                        override fun onResponse(
                                call: Call<ResultResponse>,
                                response: Response<ResultResponse>
                        ) {
                            swipeRefresh.isRefreshing=false
                            if (response.isSuccessful) {

                                response.body()?.let {
                                    recycler_view.layoutManager= GridLayoutManager(this@MainActivity,1)

                                    recycler_view.adapter= SongsAdapter(it,::openActivityDetails)
                                    //Log.d(TAG, "onResponse: ${it.size}")
                                }
                            }

                        }

                        override fun onFailure(

                                call: Call<ResultResponse>,
                                t: Throwable
                        ) {swipeRefresh.isRefreshing=false
                            println("HELLO")
                            println(call)
                            println(t)
                        }

                }
            )
        }

        else if (selectedTab.equals("Classic")){

            SongsAPI.initRetrofit().getClassicSongs().enqueue(
                    object: Callback<ResultResponse> {
                        override fun onResponse(
                                call: Call<ResultResponse>,
                                response: Response<ResultResponse>
                        ) {swipeRefresh.isRefreshing=false
                            if (response.isSuccessful) {
                                response.body()?.let {
                                    recycler_view.layoutManager= GridLayoutManager(this@MainActivity,1)

                                    recycler_view.adapter= SongsAdapter(it,::openActivityDetails)
                                    //Log.d(TAG, "onResponse: ${it.size}")
                                }
                            }

                        }

                        override fun onFailure(
                                call: Call<ResultResponse>,
                                t: Throwable
                        ) {swipeRefresh.isRefreshing=false
                            println("HELLO")
                            println(call)
                            println(t)
                        }

                    }
            )
        }
        else if (selectedTab.equals("Pop")){

            SongsAPI.initRetrofit().getPopSongs().enqueue(
                    object: Callback<ResultResponse> {
                        override fun onResponse(
                                call: Call<ResultResponse>,
                                response: Response<ResultResponse>
                        ) {swipeRefresh.isRefreshing=false
                            if (response.isSuccessful) {
                                response.body()?.let {
                                    recycler_view.layoutManager= GridLayoutManager(this@MainActivity,1)

                                    recycler_view.adapter= SongsAdapter(it,::openActivityDetails)
                                    //Log.d(TAG, "onResponse: ${it.size}")
                                }
                            }

                        }

                        override fun onFailure(
                                call: Call<ResultResponse>,
                                t: Throwable
                        ) {swipeRefresh.isRefreshing=false
                            println("HELLO")
                            println(call)
                            println(t)
                        }

                    }
            )
        }
    }

}